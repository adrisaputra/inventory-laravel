
<?php $__env->startSection('konten'); ?>
        <main class="content">
				<div class="container-fluid p-0">

					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-header">
									<h3><?php echo e(__($title)); ?></h3>
								</div>
								<div class="card-body">
									<form action="<?php echo e(url('/perkara_perdata/search')); ?>" method="GET">
									<div class="row">
										<div class="col-md-9">
											<?php if(Auth::user()->group==1): ?>
												<a href="<?php echo e(url('/perkara_perdata/create')); ?>" class="btn btn-success btn-flat" title="Tambah Data">Tambah</a>
												<a href="<?php echo e(url('/perkara_perdata')); ?>" class="btn btn-warning btn-flat" title="Refresh halaman">Refresh</a>
											<?php else: ?>
												<a href="<?php echo e(url('/perkara_perdata')); ?>" class="btn btn-warning btn-flat" title="Refresh halaman">Refresh</a>    
											<?php endif; ?>
										</div>
										<div class="col-md-3">
											<div class="input-group">
												<input type="text" class="form-control" name="search" placeholder="Cari Data">
												<span class="input-group-btn">
													<input type="submit" name="submit" class="btn btn-info btn-flat" value="Cari">
												</span>
											</div>
										</div>
									</div>
									</form><br>
									
									<?php if($message = Session::get('status')): ?>
									  <div class="alert alert-primary alert-dismissible" role="alert">
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
											<div class="alert-message">
												<?php echo e($message); ?>

											</div>
										</div>
									<?php endif; ?>
									<div class="table-responsive table-bordered">
										<table class="table mb-0">
											<thead>
											<tr style="background-color: gray;color:white">
												<th style="width: 60px">No</th>
												<th style="width: 60%">Judul</th>
												<th>Tahun</th>
												<th>Arsip</th>
												<th style="width: 16%">Aksi</th>
											</tr>
											</thead>
											<tbody>
											<?php $__currentLoopData = $perkara_perdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e(($perkara_perdata ->currentpage()-1) * $perkara_perdata ->perpage() + $loop->index + 1); ?></td>
												<td><?php echo e($v->judul); ?></td>
												<td><?php echo e($v->tahun); ?></td>
												<td>
													<?php if($v->arsip_litigasi): ?>
														<a href="<?php echo e(asset('upload/arsip_litigasi/'.$v->arsip_litigasi)); ?>" class="btn btn-sm btn-primary" >Download File</a>
													<?php endif; ?>
												</td>
												<td>
													<a href="<?php echo e(url('/perkara_perdata/edit/'.$v->id )); ?>" class="btn btn-xs btn-warning">Edit</a>
													<a href="<?php echo e(url('/perkara_perdata/hapus/'.$v->id )); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Anda Yakin ?');">Hapus</a>
												</td>
											</tr>

											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div><br>
									<div align="right"><?php echo e($perkara_perdata->appends(Request::only('search'))->links()); ?></div>
								</div>
							</div>
						</div>
					</div>
					<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
				</div>
			</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\workspace\diklat-sikasra\resources\views/admin/perkara_perdata/index.blade.php ENDPATH**/ ?>