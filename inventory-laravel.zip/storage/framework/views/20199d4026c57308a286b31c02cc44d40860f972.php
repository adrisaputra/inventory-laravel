
<?php $__env->startSection('konten'); ?>
        <main class="content">
				<div class="container-fluid p-0">

					<div class="row">
						<div class="col-12 col-xl-12">
							<div class="card">
								<div class="card-header">
									<h3>Edit <?php echo e(__($title)); ?></h3>
								</div>
								<div class="card-body">
									<form action="<?php echo e(url('/'.Request::segment(1).'/edit/'.$barang->id)); ?>" method="POST" enctype="multipart/form-data" class="form-horizontal">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" name="_method" value="PUT">
									<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right"> Barcode</label>
											<div class="col-sm-9">
												<input type="text" name="barcode" class="form-control <?php if($errors->has('barcode')): ?> is-invalid <?php endif; ?> " value="<?php echo e($barang->barcode); ?>">
												<?php if($errors->has('barcode')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('barcode')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right"> Nama Barang <span class="required" style="color: #dd4b39;">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="nama_barang" class="form-control <?php if($errors->has('nama_barang')): ?> is-invalid <?php endif; ?> " value="<?php echo e($barang->nama_barang); ?>">
												<?php if($errors->has('nama_barang')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('nama_barang')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right"> Satuan <span class="required" style="color: #dd4b39;">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="satuan" class="form-control <?php if($errors->has('satuan')): ?> is-invalid <?php endif; ?> " value="<?php echo e($barang->satuan); ?>">
												<?php if($errors->has('satuan')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('satuan')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right"> Harga Per Item <span class="required" style="color: #dd4b39;">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="harga" class="form-control <?php if($errors->has('harga')): ?> is-invalid <?php endif; ?> " value="<?php echo e(number_format($barang->harga, 0, ',', '.')); ?>" onkeyup="formatRupiah(this, '.')">
												<?php if($errors->has('harga')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('harga')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right"> Stok Awal <span class="required" style="color: #dd4b39;">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="stok" class="form-control <?php if($errors->has('stok')): ?> is-invalid <?php endif; ?> " value="<?php echo e(number_format($barang->stok, 0, ',', '.')); ?>" onkeyup="formatRupiah(this, '.')">
												<?php if($errors->has('stok')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('stok')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-sm-10 ml-sm-auto">
												<button type="submit" class="btn btn-success">Simpan</button>
												<button type="reset" class="btn btn-danger">Reset</button>
												<a href="<?php echo e(url('/'.Request::segment(1))); ?>" class="btn btn-warning">kembali</a>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
				</div>
			</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\workspace\inventory-laravel\resources\views/admin/barang/edit.blade.php ENDPATH**/ ?>