
<?php $__env->startSection('konten'); ?>
        <main class="content">
				<div class="container-fluid p-0">

					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-header">
									<h3><?php echo e(__($title)); ?></h3>
								</div>
								<div class="card-body">
									<form action="<?php echo e(url('/barang/search')); ?>" method="GET">
									<div class="row">
										<div class="col-md-9">
											<?php if(Auth::user()->group==1): ?>
												<a href="<?php echo e(url('/barang/create')); ?>" class="btn btn-success btn-flat" title="Tambah Data">Tambah</a>
												<a href="<?php echo e(url('/barang')); ?>" class="btn btn-warning btn-flat" title="Refresh halaman">Refresh</a>
											<?php else: ?>
												<a href="<?php echo e(url('/barang')); ?>" class="btn btn-warning btn-flat" title="Refresh halaman">Refresh</a>    
											<?php endif; ?>
										</div>
										<div class="col-md-3">
											<div class="input-group">
												<input type="text" class="form-control" name="search" placeholder="Cari Data">
												<span class="input-group-btn">
													<input type="submit" name="submit" class="btn btn-info btn-flat" value="Cari">
												</span>
											</div>
										</div>
									</div>
									</form><br>
									
									<?php if($message = Session::get('status')): ?>
									  <div class="alert alert-primary alert-dismissible" role="alert">
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
											<div class="alert-message">
												<?php echo e($message); ?>

											</div>
										</div>
									<?php endif; ?>
									<div class="table-responsive table-bordered">
										<table class="table mb-0">
											<thead>
											<tr style="background-color: gray;color:white">
												<th style="width: 2%">No</th>
												<th style="width: 5%">Barcode</th>
												<th style="width: 25%">Nama Barang</th>
												<th style="width: 10%">Satuan</th>
												<th style="width: 10%">Stok Saat Ini</th>
												<th style="width: 25%">Aksi</th>
											</tr>
											</thead>
											<tbody>
											<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php
													$jumlah_barang_masuk = DB::table('barang_masuk_tbl')
																		->select(DB::raw('SUM(jumlah) as total'))
																		->where('barang_id', $v->id)
																		->first();
													$jumlah_barang_keluar = DB::table('barang_keluar_tbl')
																		->select(DB::raw('SUM(jumlah) as total'))
																		->where('barang_id', $v->id)
																		->first();
												?>
											<tr>
												<td><?php echo e(($barang ->currentpage()-1) * $barang ->perpage() + $loop->index + 1); ?></td>
												<td><center>
														<!-- <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($v->barcode, 'C39')); ?>" alt="barcode" /> -->
														<!-- <?php echo DNS1D::getBarcodeHTML($v->barcode, 'C39'); ?> -->
														<img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($v->barcode, 'C39',2,70,array(1,1,1), true)); ?>" alt="barcode"   />
													</center>
												</td>
												<td><?php echo e($v->nama_barang); ?></td>
												
												<td><?php echo e($v->satuan); ?></td>
												<td><?php echo e(number_format((($v->stok + $jumlah_barang_masuk->total)-$jumlah_barang_keluar->total),0,",",".")); ?></td>
												<td>
													<a href="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($v->barcode, 'C39',2,70,array(1,1,1), true)); ?>" class="btn btn-xs btn-primary" download="<?php echo e($v->nama_barang); ?>">Download Barcode</a>
													<a href="<?php echo e(url('/barang/edit/'.$v->id )); ?>" class="btn btn-xs btn-warning">Edit</a>
													<a href="<?php echo e(url('/barang/hapus/'.$v->id )); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Anda Yakin ?');">Hapus</a>
												</td>
											</tr>

											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div><br>
									<div align="right"><?php echo e($barang->appends(Request::only('search'))->links()); ?></div>
								</div>
							</div>
						</div>
					</div>
					<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
				</div>
			</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\workspace\inventory-laravel\resources\views/admin/barang/index.blade.php ENDPATH**/ ?>