
<?php $__env->startSection('konten'); ?>
        <main class="content">
				<div class="container-fluid p-0">

					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-header">
									<h3><?php echo e(__('PEGAWAI')); ?></h3>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-md-9">
											<a href="<?php echo e(url('/pegawai/edit/'.$pegawai[0]->id)); ?>" class="btn btn-warning btn-flat" title="Edit Data Pribadi">Edit Data Pribadi</a>    
										</div>
									</div>
									</form><br>
									
									<?php if($message = Session::get('status')): ?>
									  <div class="alert alert-primary alert-dismissible" role="alert">
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
											<div class="alert-message">
												<?php echo e($message); ?>

											</div>
										</div>
									<?php endif; ?>
									<div class="table-responsive table-bordered">
										<table class="table mb-0">
											<tr>
												<td colspan=2>
													<center>
														<?php if($pegawai[0]->foto): ?>
															<img src="<?php echo e(asset('storage/upload/foto_pegawai/thumbnail/'.$pegawai[0]->foto)); ?>" class="img-circle" alt="User Image"  width="150px" height="150px">
														<?php else: ?>
															<img src="<?php echo e(asset('upload/user/15.jpg')); ?>" class="img-circle" alt="User Image" width="150px" height="150px">
														<?php endif; ?>
														<br><br>
														<p style="font-size:22px;font-weight:bold"><?php echo e($pegawai[0]->nama_pegawai); ?></p>
														<p style="font-size:18px;font-weight:bold"><?php echo e($pegawai[0]->nip); ?></p>
													</center>
												</td>
											</tr>
											<tr style="background-color: #2196f3;color:white">
												<th style="width: 200px;text-align:center;font-size:16px" colspan=2>DATA PRIBADI</th>
											</tr>
											<tr>
												<th style="width: 200px">Tempat Tanggal Lahir</th>
												<td>: <?php echo e($pegawai[0]->tempat_lahir); ?>, <?php echo e(date('d-m-Y', strtotime($pegawai[0]->tanggal_lahir))); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">Jenis Kelamin</th>
												<td>: <?php echo e($pegawai[0]->jenis_kelamin); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">Alamat</th>
												<td>: <?php echo e($pegawai[0]->alamat); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">Agama</th>
												<td>: <?php echo e($pegawai[0]->agama); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">Gol. Darah</th>
												<td>: <?php echo e($pegawai[0]->gol_darah); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">Email</th>
												<td>: <?php echo e($pegawai[0]->email); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">No. Telepon</th>
												<td>: <?php echo e($pegawai[0]->telp); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">No. KTP</th>
												<td>: <?php echo e($pegawai[0]->no_ktp); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">No. BPJS</th>
												<td>: <?php echo e($pegawai[0]->no_bpjs); ?></td>
											</tr>
											<tr>
												<th style="width: 200px">Nomor NPWP</th>
												<td>: <?php echo e($pegawai[0]->no_npwp); ?> </td>
											</tr>
											<tr>
												<th style="width: 200px">Nomor Karpeg</th>
												<td>: <?php echo e($pegawai[0]->no_karpeg); ?> </td>
											</tr>
											<tr>
												<th style="width: 200px">No. Karsu/Karis</th>
												<td>: <?php echo e($pegawai[0]->no_karsu); ?> </td>
											</tr>
											<tr>
												<th style="width: 200px">TMT CPNS</th>
												<td>: <?php echo e(date('d-m-Y', strtotime($pegawai[0]->tmt_cpns))); ?> </td>
											</tr>
											<tr>
												<th style="width: 200px">TMT PNS</th>
												<td>: <?php echo e(date('d-m-Y', strtotime($pegawai[0]->tmt_pns))); ?> </td>
											</tr>
										</table>
									</div><br>
								</div>
							</div>
						</div>
					</div>
					<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
				</div>
			</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\workspace\diklat-sikasra\resources\views/admin/pegawai/index2.blade.php ENDPATH**/ ?>