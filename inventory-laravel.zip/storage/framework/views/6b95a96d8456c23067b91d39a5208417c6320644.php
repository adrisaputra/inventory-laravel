
<?php $__env->startSection('konten'); ?>
        <main class="content">
				<div class="container-fluid p-0">

					<div class="row">
						<div class="col-12 col-xl-12">
							<div class="card">
								<div class="card-header">
									<h3>Tambah <?php echo e(__($title)); ?></h3>
								</div>
								<div class="card-body">
									<form action="<?php echo e(url('/'.Request::segment(1))); ?>" method="POST" enctype="multipart/form-data" class="form-horizontal">
										<?php echo e(csrf_field()); ?>

										
										<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right"> <?php echo e(__('Tanggal Masuk')); ?> <span class="required" style="color: #dd4b39;">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="tanggal" class="form-control <?php if($errors->has('tanggal')): ?> is-invalid <?php endif; ?> " placeholder="Tanggal Pinjam" value="<?php echo e(old('tanggal')); ?>">
												<?php if($errors->has('tanggal')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('tanggal')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right"> <?php echo e(__('Barang')); ?>  <span class="required" style="color: #dd4b39;">*</span></label>
											<div class="col-sm-9">
												<select class="form-control select2 <?php if($errors->has('barang_id')): ?> is-invalid <?php endif; ?>" name="barang_id">
													<option value="">- Pilih -</option>
													<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($v->id); ?>"><?php echo e($v->barcode); ?> || <?php echo e($v->nama_barang); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
												<?php if($errors->has('barang_id')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('barang_id')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right">  <?php echo e(__('Jumlah')); ?> <span class="required" style="color: #dd4b39;">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="jumlah" class="form-control <?php if($errors->has('jumlah')): ?> is-invalid <?php endif; ?> " value="<?php echo e(old('jumlah')); ?>" onkeyup="formatRupiah(this, '.')">
												<?php if($errors->has('jumlah')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('jumlah')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-form-label col-sm-3 text-sm-right"> <?php echo e(__('Keterangan')); ?></label>
											<div class="col-sm-9">
												<textarea id="konten" name="keterangan" class="form-control <?php if($errors->has('keterangan')): ?> is-invalid <?php endif; ?> " rows="3"><?php echo e(old('keterangan')); ?></textarea>
												<?php if($errors->has('keterangan')): ?> <label id="validation-email-error" class="error jquery-validation-error small form-text invalid-feedback" for="validation-email"><?php echo e($errors->first('keterangan')); ?></label><?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-sm-10 ml-sm-auto">
												<button type="submit" class="btn btn-success">Simpan</button>
												<button type="reset" class="btn btn-danger">Reset</button>
												<a href="<?php echo e(url('/'.Request::segment(1))); ?>" class="btn btn-warning">kembali</a>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
				</div>
			</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\workspace\inventory-laravel\resources\views/admin/barang_masuk/create.blade.php ENDPATH**/ ?>